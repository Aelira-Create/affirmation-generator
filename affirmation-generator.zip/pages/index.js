import { useState } from 'react';

export default function Home() {
  const [keyword, setKeyword] = useState('');
  const [affirmation, setAffirmation] = useState('');

  const generate = () => {
    const affirmationTemplate = `I am always attracting ${keyword} into my life with ease and joy.`;
    setAffirmation(affirmationTemplate);
  };

  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Affirmation Generator</h1>
      <input
        type="text"
        placeholder="Enter a keyword..."
        value={keyword}
        onChange={(e) => setKeyword(e.target.value)}
        style={{ padding: '0.5rem', fontSize: '1rem' }}
      />
      <button onClick={generate} style={{ marginLeft: '1rem', padding: '0.5rem 1rem' }}>
        Generate
      </button>
      {affirmation && (
        <p style={{ marginTop: '2rem', fontSize: '1.2rem', fontWeight: 'bold' }}>{affirmation}</p>
      )}
    </div>
  );
}
